# NodeJSChatServer
#### Socket io chat server made with node js 

## Installation

* clone the projet from the git repository 
* under your project directory execute this command 

```
$ npm install 
```
*this will install all the required dependencies 

* run your project using the following command 

```
$ node server.js
```
 
 * your project will run on htttp://localhost:3000/
